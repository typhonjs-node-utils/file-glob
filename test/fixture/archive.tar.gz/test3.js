
/**
 * A comment.
 */
export default class Test
{
   constructor()
   {
      this.test = true;
   }
}
